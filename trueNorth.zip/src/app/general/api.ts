export const url = {
    "search": "https://api.github.com/users/",
    "users": "https://docs.github.com/en/rest/reference/search#undefined",
    "history": "https://docs.github.com/en/rest/reference/search#undefined",
}